public class EmpresaException extends Exception{

    public EmpresaException(String message) {
        super(message);
    }
}
